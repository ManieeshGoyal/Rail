{!! \App\Helpers\Input::textField('meta_title', 'Meta Title', FALSE, '', $meta_title) !!}
{!! \App\Helpers\Input::textAreaField('meta_description', 'Meta Description', FALSE, '', $meta_description) !!}
{!! \App\Helpers\Input::textField('meta_keywords', 'SEO Keywords', FALSE, '', $meta_keywords) !!}
{!! \App\Helpers\Input::textField('canonical', 'Canonical Link', FALSE, '', $canonical) !!}