<title>{{ $meta_title }}{{ $pagination }}{{ $seperator }}{{ config('app.name') }}</title>
<meta name="og:title" content="{{ $meta_title }}{{ $pagination }}{{ $seperator }}{{ config('app.name') }}">
<meta name="description" content="{{ $meta_description }}{{ $pagination }}">
<meta name="og:description" content="{{ $meta_description }}{{ $pagination }}">
<meta name="keywords" content="{{ $meta_keywords }}{{ $pagination }}">
<link rel="canonical" href="{{ $canonical }}">